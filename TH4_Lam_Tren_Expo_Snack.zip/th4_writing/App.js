import { StyleSheet, View, Text, TouchableOpacity, ScrollView, TextInput, Image} from 'react-native';

export default function App() {
  const Categories =[
    {name: 'resort', image:'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/ee6c4ea8d3c4f4335a64a5cc2578cd96'},
    { name: 'Homestay', image: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/2f604cfb3f13ee3798798b4353c777fd' },
    { name: 'Hotel', image: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/63f2ef477c4aa3c784e05fa007e2584f' },
    { name: 'Lodge', image: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/3f2a222146befc7f501c16bc2a4e8824' },
    { name: 'Villa', image: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/a38c39a7a88d7d7ecce6d1bf4551f328' },
    { name: 'Apartment', image: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/ac21589354ee18d454cd20815520dee6'},
    { name: 'Hostel', image: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/aa09106f06854c606d90ec07f5a074e7' },
    { name: 'See all', image: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/a7f990fa9bcad7dd07fae6fec3f2ae3b' },
  ];
  const navItems =[
    {name:'Home', icon:'home',image:'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/ae5fffbcdf3e5747a14de530fae0894d'},
    { name: 'Explore', icon: 'compass', image: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/4cbdc108a650ba8818a2fbb588fd72f9' },
    { name: 'Search', icon: 'search', image: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/4b2b0a7af42dc5eebd866a3d3e5c6b5e' },
    { name: 'User', icon: 'user', image: 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/d35b387f2602ced53af0f91af681cd13' },
];

  return(
    <ScrollView style={styles.container}>
      <View style={styles.flex1} >
      <View style={styles.logo} >
        <Image source={{uri:'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/006bd8546804b4cf6fbb0170c0adeda4'}} style={styles.logo1}/>
        <View style={styles.searchcontainer} >
          <TextInput style={styles.searchInput} placeholder ="Search here ..." />
          <Image source={{uri:'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/6354db7495a3ef2a0a22b13a6ec9469d'}} style={styles.findicon}/>
        </View>
        </View>
        <View style={styles.topBar}>
          <View style={styles.topBar1}>
            <Image source={{uri:'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/72c2b7de41006140885cf126e6f88e2d'}} style={styles.personicon}/>
            <View style={styles.textof2}>
              <Text style={styles.text1}>Welcome ! </Text>
              <Text style={styles.text1} >Donna Stroupe </Text>
            </View>
          </View>
          <Image source={{uri:'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/49abcceea53ec149b6a87fe3f86d7e92'}} style={styles.ringicon} />
        </View>
        </View>

        <View style={styles.section} >
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Category </Text>
            <Image source={{uri:'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/75cd4723abe21457d6519d8952c6f685'}} style={styles.threeGach} />
          </View>
          <View style={styles.categoryContainer}>
            {Categories.map((category, index) => (
              <TouchableOpacity key={index} style={styles.categoryItem}>
              <Image source={{ uri: category.image }} style={styles.categoryImage}/>
              <Text style={styles.categoryText}>{category.name} </Text>
              </TouchableOpacity>
            ))}
          </View>
      </View>

      <View style={styles.section}>
        <View style={styles.plus}>
        <Text style={styles.sectionTitle}> Popular Destination  </Text>
        <Image source={{uri:'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/75cd4723abe21457d6519d8952c6f685'}} style={styles.threeGach1} />
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {['https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/4dbc7f633fd20d1a34b6405b5059c5d0', 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/2364f03e5953c3509940407143e7a765', 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/e78fe10ddd40a80be0d68b137e907541'].map((image,index)=>(
          <Image key={index} source={{uri:image}} style={styles.destinationImage} />
          ))}
        </ScrollView>
      </View>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Recommended</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {['https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/e82917ff6b605b9eaac2b0682f3f5750', 'https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/37e0a23c3f291d8c6ceb1243ec5daef9'].map((image, index) => (
            <Image key={index} source={{ uri: image }} style={styles.destinationImage} />
          ))}
        </ScrollView>
      </View>

      <View style={styles.bottomNav}>
        {navItems.map((item, index) => (
          <TouchableOpacity key={index} style={styles.navItem}>
            <Image source={{ uri: item.image }} style={styles.navIcon} />
            <Text style={styles.navText}>{item.name}</Text>
          </TouchableOpacity>
        ))}
      </View>

    </ScrollView>

    

  );
}
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffff',
    height: '100%',
    width: '100%',
  },
  flex1: {
    backgroundColor: '#5c5cb4',
  },
  logo: {
    flexDirection: 'row',
    alignContent: 'center',
    marginLeft: 30,
    marginTop: 20,
  },
  logo1: {
    width: 40,
    height: 40,
  },
  searchcontainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    marginLeft: 20,
    borderRadius: 10,
    paddingVertical: 5,
    paddingHorizontal: 10,
  },
  searchInput: {
    flex: 1,
    paddingHorizontal: 10,
  },
  findicon: {
    width: 30,
    height: 30,
    marginLeft: 10,
  },
  personicon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginLeft: 35,
  },
  section: {
    marginTop: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
  },
  sectionTitle:{
    padding:20,
    fontSize: 18,
    fontWeight: 'bold',
  },
  text1: {
    fontSize:16,
  },
  ringicon: {
    width: 40,
    height: 40,
    marginRight: 35,
  },
  topBar1: {
    alignItems: 'center',
    flexDirection: 'row',
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  textof2: {
    marginLeft: 10,
    flexDirection:'row'
  },
  threeGach: {
    width: 30,
    height: 30,
    marginRight: 20,
  },
  threeGach1: {
    width: 30,
    height: 30,
    marginRight: 40,
    marginTop:10,
  },
  bottomNav: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#5c5cb4',
    paddingVertical: 10,
    marginTop:10,
  },
  navItem: {
    alignItems: 'center',
  },
  navText: {
    color: '#fff',
    marginTop: 5,
    fontSize: 12,
  },
  navIcon: {
    width: 24,
    height: 24,
  },
  categoryContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    padding: 10,
  },
  categoryItem: {
    alignItems: 'center',
    margin: 10,
    width: '17%', 
  },
  categoryText: {
    fontSize: 12,
    fontWeight: 'bold',
    marginTop: 5,
  },
  categoryImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginBottom: 5,
  },
  destinationImage: {
    width: 100,
    height: 100,
    borderRadius: 10,
    marginHorizontal: 5,
  },
  plus:{
    justifyContent:'space-between',
    flexDirection:'row',
    alignContent:'center'
  },
});